Building and installing the CycleClustering application
======================================================

Please refer to the INSTALL_APPLICATIONS_EXAMPLES.md file in the scip directory.
